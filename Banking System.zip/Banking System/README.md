# This is Banking System project
    In this hase two section 

    1. employee login
        See transation 
        Credit amount 
        Debit amount
        Create new customer account
        Update customer account details

    2. admin login
        Employee information
        Employee account list
        Employee payment
        Add new employee
        